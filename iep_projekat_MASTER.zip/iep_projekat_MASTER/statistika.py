'''import os
from pyspark.sql import SparkSession;

#izbacivanje svih reci koje nemaju spark u sebi

data=[
    "I love Python",
    "I love Spark"
];

#spark= SparkSession.builder.appName("PySpark Example").master("local[*]").getOrCreate()
builder=SparkSession.builder.appName("PySpark Example");

if("PRODUCTION" not in os.environ ) :#moze i u lokalu i u klasteru
    builder=builder.master("local[*]")

spark=builder.getOrCreate()
spark.sparkContext.setLogLevel("ERROR") # DA nam se ne ispisje gomila ne potrebnih poruka

rdd=spark.sparkContext.parallelize(data) #nad ovim objektom pisemo operacije koje ce raditi nad kontekstom

rdd=rdd.filter(lambda item:item.find("Spark")!=-1) #da li data recenica ima string Spark, prosledjujemo lambdu koja ce se izvrsiti nad svim elementima liste data

result=rdd.collect()

print(result)

spark.stop()'''

from flask import Flask
from flask import jsonify
from flask import Response
import os
import subprocess
import json

application=Flask(__name__)

def extract_json(input_string):
    lines = input_string.split('\n')  # Razdvajanje stringa na linije na osnovu znaka za prelazak u novi red
    print(lines,flush=True)
    json_line = lines[-2]  # Poslednja linija sadrži JSON objekat
    json_data = json_line.strip()  # Uklanjanje eventualnih razmaka na početku ili kraju linije
    #json_data=json_data.replace("'","");
    return json_data

def process_json(json_string):
    data = json.loads(json_string)
    statistics = data['statistics']

    # Izbaci elemente sa waiting i sold postavljenim na null
    statistics = [item for item in statistics if item['waiting']!=0 or item['sold']!=0]

    # Zameni preostale null vrednosti sa 0
    for item in statistics:
        if item['waiting']==0:
            item['waiting'] = 0
        if item['sold']==0:
            item['sold'] = 0

    data["statistics"] =statistics;
    # Konvertuj rezultujući niz u JSON string
    processed_json = json.dumps(data)

    return data

@application.route("/",methods=["GET"])
def database_product_statistics():
    os.environ["SPARK_APPLICATION_PYTHON_LOCATION"] = "/app/proizvod_statistika.py"

    os.environ["SPARK_SUBMIT_ARGS"] = "--driver-class-path /app/mysql-connector-j-8.0.33.jar --jars /app/mysql-connector-j-8.0.33.jar"

    #result = subprocess.check_output(["/template.sh"])
    print("poziv",flush=True)
    # Izvršavanje skripte proizvod_statistika.py
    #subprocess.call(["python", "/app/proizvod_statistika.py"])
    result=subprocess.check_output(["/template.sh"]).decode()

    # Učitavanje statistike iz datoteke
    #with open("/app/product_statistics.json", "r") as file:
    #   data = json.load(file)
    print(result,flush=True)
    # Uklanjanje datoteke
    #os.remove("/app/product_statistics.json")
    result=extract_json(result)
    print(result,flush=True)
    # Vraćanje statistike kao odgovor
    #return jsonify(data), 200
    #result=json.loads(result.split("\n")[0])
    result=process_json(result);
    print(result,flush=True)

    return jsonify(result),200


    #return result.decode()

    '''result = subprocess.check_output(["/template.sh"])
    return result.decode()'''

@application.route("/kategorija",methods=["GET"])
def database_category_statistics():
    os.environ["SPARK_APPLICATION_PYTHON_LOCATION"] = "/app/kategorije_statistika.py"

    os.environ["SPARK_SUBMIT_ARGS"] = "--driver-class-path /app/mysql-connector-j-8.0.33.jar --jars /app/mysql-connector-j-8.0.33.jar"

    result = subprocess.check_output(["/template.sh"]).decode()
    print(result,flush=True)
    result=extract_json(result)
    print(result,flush=True)

    # Vraćanje odgovora kao JSON objekta
    return jsonify(json.loads(result)),200

    #return result.decode()


if(__name__=="__main__"):
    #print(database_product_statistics())
    #print(database_category_statistics())
    application.run(debug=True,host="0.0.0.0")
