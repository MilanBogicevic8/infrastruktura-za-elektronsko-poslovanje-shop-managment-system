from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.functions import when,lit
from pyspark.sql import functions as F

import os
import json
import pprint

PRODUCTION = False if ("PRODUCTION" in os.environ) else False
DATABASE_IP = os.environ["DATABASE_IP"] if ("DATABASE_IP" in os.environ) else "localhost"

builder = SparkSession.builder.appName("PySpark Database Product_Statistics")
PRODUCTION=True

if (not PRODUCTION):
    builder = builder.master("local[*]") \
        .config(
        "spark.driver.extraClassPath",
        "mysql-connector-j-8.0.33.jar"
    )

#print(PRODUCTION)
#print(DATABASE_IP)

spark = builder.getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

product_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3306/shop") \
    .option("dbtable", "shop.product") \
    .option("user", "root") \
    .option("password", "root") \
    .load()

order_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3306/shop") \
    .option("dbtable", "shop.order") \
    .option("user", "root") \
    .option("password", "root") \
    .load()

product_order_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3306/shop") \
    .option("dbtable", "shop.product_order") \
    .option("user", "root") \
    .option("password", "root") \
    .load()

category_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3306/shop") \
    .option("dbtable", "shop.category") \
    .option("user", "root") \
    .option("password", "root") \
    .load()

product_category_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3306/shop") \
    .option("dbtable", "shop.product_category") \
    .option("user", "root") \
    .option("password", "root") \
    .load()

# Spajanje podataka i izračunavanje statistike
joined_data_frame = product_data_frame.join(
    product_order_data_frame,
    product_data_frame["id"] == product_order_data_frame["product_id"],
    "left"
).join(
    order_data_frame,
    product_order_data_frame["order_id"] == order_data_frame["id"],
    "left"
).join(
    product_category_data_frame,
    product_data_frame["id"] == product_category_data_frame["product_id"],
    "left"
).join(
    category_data_frame,
    product_category_data_frame["category_id"] == category_data_frame["id"],
    "left"
)

# Izračunavanje statistike
category_statistics_data_frame = joined_data_frame.groupBy(category_data_frame["naziv"]).agg(
    F.sum(when(order_data_frame["status"] == "COMPLETE", product_order_data_frame["kolicina"]).otherwise(lit(0))).alias("quantity")
)

# Sortiranje statistike
sorted_category_statistics_data_frame = category_statistics_data_frame.orderBy(
    col("quantity").desc(),
    col("naziv").asc()
)

# Konvertovanje DataFrame u listu
statistics = sorted_category_statistics_data_frame.select("naziv").rdd.map(lambda row: row[0]).collect()

# Kreiranje odgovora
response = {
    "statistics": statistics
}

# Ispis rezultata pre vraćanja
pprint.pprint(response)

# Za format identičan funkciji category_statistics,
# možete koristiti JSON biblioteku da konvertujete response u JSON string
json_response = json.dumps(response)

# Vraćanje JSON response
print(json_response)


spark.stop()