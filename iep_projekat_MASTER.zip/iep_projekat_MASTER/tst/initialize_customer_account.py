from web3 import Web3
from web3 import HTTPProvider 
from web3 import Account


private_key = ""
with open ( "keys.json", "r" ) as file:
    private_key = Account.decrypt ( file.read ( ), "iep_project" ).hex ( )

customer_account = Account.from_key ( private_key )

web3 = Web3 ( HTTPProvider ( "http://127.0.0.1:8545" ) )

print(customer_account)
print(private_key)
print(web3.eth.accounts[0])
print(web3.eth.accounts)
result = web3.eth.send_transaction ({
    "from": web3.eth.accounts[0],
    "to": customer_account.address,
    "value": web3.to_wei ( 2, "ether" )
})

print(customer_account.address)
print(web3.eth.get_balance(customer_account.address))
print(web3.eth.get_balance(web3.eth.accounts[0]))
