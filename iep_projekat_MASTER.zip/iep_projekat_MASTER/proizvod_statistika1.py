from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql import functions as F
#from pyspark.sql.types import StringType
import os
import json
import pprint



builder = SparkSession.builder.appName("PySpark Database Product_Statistics")


builder = builder.master("local[*]") \
        .config(
        "spark.driver.extraClassPath",
        "mysql-connector-j-8.0.33.jar"
)

#print(PRODUCTION)
#print(DATABASE_IP)
#print("usao",flush=True)
spark = builder.getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

product_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3306/shop") \
    .option("dbtable", "shop.product") \
    .option("user", "root") \
    .option("password", "root") \
    .load()

#product_data_frame.show()
#print(product_data_frame,flush=True)
order_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3306/shop") \
    .option("dbtable", "shop.order") \
    .option("user", "root") \
    .option("password", "root") \
    .load()
#product_data_frame.show()
#print(order_data_frame,flush=True)
product_order_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3306/shop") \
    .option("dbtable", "shop.product_order") \
    .option("user", "root") \
    .option("password", "root") \
    .load()
#product_order_data_frame.show()
#print(product_order_data_frame,flush=True)
# people_data_frame.show ( )
# result = people_data_frame.filter ( people_data_frame["gender"] == "Male" ).collect ( )
# print ( result )

#result = people_data_frame.join(
#    messages_data_frame,
#    messages_data_frame["person_id"] == people_data_frame["id"]
#).groupBy(people_data_frame["first_name"]).count().collect()
#print(result)

# Spajanje podataka i izračunavanje statistike
# Spajanje podataka i izračunavanje statistike
# Spajanje podataka i izračunavanje statistike
joined_data_frame = product_data_frame.join(
    product_order_data_frame,
    product_data_frame["id"] == product_order_data_frame["product_id"]
).join(
    order_data_frame,
    product_order_data_frame["order_id"] == order_data_frame["id"]
)

# Izračunavanje prodanih i čekajućih proizvoda po nazivu
statistics_data_frame = joined_data_frame.groupBy(product_data_frame["naziv"]).agg(
    F.sum(F.when(order_data_frame["status"] == "COMPLETE", product_order_data_frame["kolicina"])).alias("sold"),
    F.sum(F.when(order_data_frame["status"] != "COMPLETE", product_order_data_frame["kolicina"])).alias("waiting")
)

# Konvertovanje DataFrame u listu objekata statistike
statistics = statistics_data_frame.rdd.map(lambda row: {
    "name": row["naziv"],
    "sold": row["sold"],
    "waiting": row["waiting"]
}).collect()

# Kreiranje odgovora
response = {
    "statistics": statistics
}

# Ispis rezultata pre vraćanja
#pprint.pprint(response)

# Za format identičan funkciji product_statistics
json_response = json.dumps(response)

# Vraćanje JSON response i odgovarajućeg status koda
print(json_response)


spark.stop()

