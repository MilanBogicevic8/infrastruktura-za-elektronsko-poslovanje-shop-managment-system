import jaydebeapi
import os
os.environ['JAVA_OPTS'] = '-Xmx4g'
# Podešavanje parametara veze
driver_class = "com.mysql.cj.jdbc.Driver"
url = "jdbc:mysql://shopDb:3307/shop"
username = "root"
password = "root"

try:
    # Pokušajte uspostaviti vezu sa bazom podataka
    conn = jaydebeapi.connect(driver_class, url, [username, password])

    # Veza je uspešno uspostavljena
    print("Veza sa bazom podataka je uspostavljena.")

    # Zatvorite vezu
    conn.close()

except Exception as e:
    # Greška prilikom uspostavljanja veze
    print("Greška prilikom uspostavljanja veze sa bazom podataka:", str(e))
