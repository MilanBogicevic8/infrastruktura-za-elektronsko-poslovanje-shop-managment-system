import shutil

from flask import Flask
from configuration import Configuration
from flask_migrate import Migrate
from flask_migrate import init
from flask_migrate import migrate
from flask_migrate import upgrade
from models import database
from models import User
from models import UserRole
from models import Role
from sqlalchemy_utils import database_exists, create_database
from sqlalchemy_utils import drop_database


app = Flask(__name__)
app.config.from_object(Configuration)

migrateObject = Migrate(app, database)

if database_exists(app.config['SQLALCHEMY_DATABASE_URI']):
    drop_database(app.config['SQLALCHEMY_DATABASE_URI'])

create_database(app.config['SQLALCHEMY_DATABASE_URI'])

database.init_app(app)

with app.app_context() as context:
    try:
        shutil.rmtree('migrations')
    except Exception:
        pass

    init()
    migrate(message='Production migration')
    upgrade()

    ownerRole = Role(name='owner')
    customerRole = Role(name='customer')
    courierRole = Role(name='courier')

    database.session.add(ownerRole)
    database.session.add(customerRole)
    database.session.add(courierRole)
    database.session.commit()

    #pravimo ownera prvo
    owner = User(
        email='onlymoney@gmail.com',
        password='evenmoremoney',
        forename='Scrooge',
        surname='McDuck'
    )

    database.session.add(owner)
    database.session.commit()

    userRole = UserRole(
        user_id=owner.id,
        role_id=ownerRole.id
    )

    database.session.add(userRole)
    database.session.commit()

