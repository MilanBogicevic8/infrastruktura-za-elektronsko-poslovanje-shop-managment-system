import json
import re
from flask import Flask
from flask import request
from flask import Response
from flask import jsonify
from sqlalchemy import and_
from models import User
from models import Role
from models import UserRole
from models import database
from configuration import Configuration
from flask_jwt_extended import JWTManager
from flask_jwt_extended import create_access_token
from flask_jwt_extended import jwt_required
from flask_jwt_extended import get_jwt_identity

application=Flask(__name__);
application.config.from_object(Configuration)

jwt=JWTManager(application);

@application.route("/",methods=["GET"])
def index():
    return "Hello world!";

@application.route("/register_customer",methods=["POST"])
def register_cust():
    email = request.json.get("email", "");
    password = request.json.get("password", "")
    forename = request.json.get("forename", "")
    surname = request.json.get("surname", "")

    #provera da li su sva polja poslata
    if len(forename) == 0:
        return {'message': "Field forename is missing."}, 400
    if len(surname) == 0:
        return {'message': "Field surname is missing."} ,400
    if len(email) == 0:
        return {'message': "Field email is missing."}, 400
    if len(password) == 0:
        return {'message': "Field password is missing."}, 400




    #provera da li je mejl odgovarajuc pomocu regexa
    regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    if len(email)>256 or not re.fullmatch(regex, email):
        return {'message': "Invalid email."}, 400

    #proera da li je ozinka duza od 8 karaktera
    if ( len(password) < 8):
        return {'message': "Invalid password."}, 400

    #provera da li korisnik sa tim mejlom vec postoji u bazi
    user = User.query.filter(User.email == email).first()
    if user:
        return {'message': "Email already exists."}, 400

    #cuvanje korisnika
    user = User( password=password, forename=forename, surname=surname,email=email)
    database.session.add(user)
    database.session.commit()

    role=Role.query.filter(Role.name=="customer").first();
    userRole = UserRole(user_id=user.id, role_id=role.id)
    database.session.add(userRole)
    database.session.commit()

    return {}, 200

@application.route("/register_courier",methods=["POST"])
def register_curir():
    email = request.json.get("email", "");
    password = request.json.get("password", "")
    forename = request.json.get("forename", "")
    surname = request.json.get("surname", "")

    #provera da li su sva polja poslata
    if len(forename) == 0:
        return {'message': "Field forename is missing."}, 400
    if len(surname) == 0:
        return {'message': "Field surname is missing."}, 400
    if len(email) == 0:
        return {'message': "Field email is missing."}, 400
    if len(password) == 0:
        return {'message': "Field password is missing."}, 400




    #provera da li je mejl odgovarajuc pomocu regexa
    regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    if len(email)>256 or not re.fullmatch(regex, email):
        return {'message': "Invalid email."}, 400

    #proera da li je ozinka duza od 8 karaktera
    if ( len(password) < 8):
        return {'message': "Invalid password."}, 400

    #provera da li korisnik sa tim mejlom vec postoji u bazi
    user = User.query.filter(User.email == email).first()
    if user:
        return {'message': "Email already exists."}, 400

    #cuvanje kurira
    user = User( password=password, forename=forename, surname=surname,email=email)
    database.session.add(user)
    database.session.commit()

    role=Role.query.filter(Role.name=="courier").first();
    userRole = UserRole(user_id=user.id, role_id=role.id)
    database.session.add(userRole)
    database.session.commit()

    return {}, 200

def get_user_type(role_names):
    if "admin" in role_names:
        return "admin"
    elif "customer" in role_names:
        return "customer"
    elif "courier" in role_names:
        return "courier"
    else:
        return "unknown"

@application.route("/login",methods=["POST"])
def login( ):
    password = request.json.get("password", "")
    email = request.json.get("email", "")

    #ponovo provera da li su polja lepo poslata, ispravna duzina
    if len(email) == 0:
        return {'message': "Field email is missing."}, 400

    if len(password) == 0:
        return {'message': "Field password is missing."}, 400

    # ispravan mejl
    regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    if len(email)>256 or not re.fullmatch(regex, email):
        return {'message': "Invalid email."} , 400





    #da li korisnik postoji u bazi
    user = User.query.filter(and_(User.email == email, User.password == password)).first()
    if not user:
        return {'message': "Invalid credentials."} , 400

    role_names = [role.name for role in user.roles]
    user_type = get_user_type(role_names)  # Funkcija koja vraća tip korisnika na osnovu uloga

    '''additionalClaims = {
        "sub": user.email,
        "forename": user.forename,
        "surname": user.surname,
        "roles": str(user.roles),
        "email": user.email

    }'''

    additionalClaims = {
        "forename": user.forename,
        "surname": user.surname,
        "roles": str(user.roles[0]),
        "email": user.email


    }

    accessToken = create_access_token(identity=user.email, additional_claims=additionalClaims);

    return {"accessToken":accessToken}, 200

@application.route("/delete",methods=["POST"])
@jwt_required()
def delete( ):
    #email = request.json.get("email", "")
    #izgleda da se u testu ne salje email,, sva sreca da ga ima u jwt zaglavluju :)
    email=get_jwt_identity()
    #if len(email) == 0:
    #    return Response(json.dumps({'message': ""}), status=400)

    #provera formata mejla, ponovo....
    #regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
   # if not re.fullmatch(regex, email):
    #    return Response(json.dumps({'message': "Invalid email."}), status=400)


    #provera da li postoji korisnik, ponovo ....
    user = User.query.filter(User.email == email).first()
    if not user:
        return {'message': "Unknown user."}, 400

    #brisanje
    database.session.delete(user)
    database.session.commit()

    return {},200


if(__name__=="__main__"):
    database.init_app(application)
    application.run(debug=True,host="0.0.0.0");