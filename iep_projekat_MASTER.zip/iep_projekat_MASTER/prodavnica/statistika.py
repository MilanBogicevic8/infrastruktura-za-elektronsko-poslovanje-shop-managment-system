'''import os
from pyspark.sql import SparkSession;

#izbacivanje svih reci koje nemaju spark u sebi

data=[
    "I love Python",
    "I love Spark"
];

#spark= SparkSession.builder.appName("PySpark Example").master("local[*]").getOrCreate()
builder=SparkSession.builder.appName("PySpark Example");

if("PRODUCTION" not in os.environ ) :#moze i u lokalu i u klasteru
    builder=builder.master("local[*]")

spark=builder.getOrCreate()
spark.sparkContext.setLogLevel("ERROR") # DA nam se ne ispisje gomila ne potrebnih poruka

rdd=spark.sparkContext.parallelize(data) #nad ovim objektom pisemo operacije koje ce raditi nad kontekstom

rdd=rdd.filter(lambda item:item.find("Spark")!=-1) #da li data recenica ima string Spark, prosledjujemo lambdu koja ce se izvrsiti nad svim elementima liste data

result=rdd.collect()

print(result)

spark.stop()'''

from flask import Flask
from flask import jsonify
import os
import subprocess
import json

application=Flask(__name__)

def database_product_statistics():
    os.environ["SPARK_APPLICATION_PYTHON_LOCATION"] = "/app/proizvod_statistika.py"

    os.environ["SPARK_SUBMIT_ARGS"] = "--driver-class-path /app/mysql-connector-j-8.0.33.jar --jars /app/mysql-connector-j-8.0.33.jar"

    result = subprocess.check_output(["/template.sh"])

    # Učitavanje statistike iz datoteke
    with open("/app/product_statistics.json", "r") as file:
        data = json.load(file)

    # Uklanjanje datoteke
    os.remove("/app/product_statistics.json")

    # Vraćanje statistike kao odgovor
    return jsonify(data), 200


    #return result.decode()


def database_category_statistics():

    os.environ["SPARK_APPLICATION_PYTHON_LOCATION"] = "/app/kategorije_statistika.py"

    os.environ["SPARK_SUBMIT_ARGS"] = "--driver-class-path /app/mysql-connector-j-8.0.33.jar --jars /app/mysql-connector-j-8.0.33.jar"

    result = subprocess.check_output(["/template.sh"])

    import os
    import json

    # Učitavanje statistike iz datoteke
    with open("/app/rezultati.json", "r") as file:
        data = file.read().rstrip(",")

    # Uklanjanje datoteke
    os.remove("/app/rezultati.json")

    # Kreiranje odgovora u traženom formatu
    response = {
        "statistics": data.split(",")
    }

    # Vraćanje odgovora kao JSON objekta
    return json.dumps(response), 200

    #return result.decode()


if(__name__=="__main__"):
    print(database_product_statistics())
    print(database_category_statistics())
    application.run()