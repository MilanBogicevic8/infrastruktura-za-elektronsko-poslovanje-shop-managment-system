# Skripta za kompajliranje Solidity ugovora

# Ukloni output folder ako već postoji
Remove-Item ./solidity/output -Recurse -ErrorAction Ignore

# Pokreni Docker kontejner za kompajliranje
docker run --rm -v ${PWD}/solidity:/sources ethereum/solc:0.8.18 -o /sources/output --abi --bin /sources/PurchaseContract.sol

# Prikazivanje poruke kada je kompajliranje završeno
Write-Host "Kompajliranje završeno! Proverite output folder."
