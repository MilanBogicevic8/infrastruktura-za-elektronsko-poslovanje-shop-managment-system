from pyspark.sql import SparkSession
from pyspark.sql.functions import col

import os
import json

PRODUCTION = False if ("PRODUCTION" in os.environ) else False
DATABASE_IP = os.environ["DATABASE_IP"] if ("DATABASE_IP" in os.environ) else "localhost"
PRODUCTION=True
builder = SparkSession.builder.appName("PySpark Database Product_Statistics")  #.config("spark.jars", "mysql:mysql-connector-java:8.0.13").getOrCreate()
'''
if (not PRODUCTION):
    builder = builder.master("local[*]") \
        .config(
        "spark.driver.extraClassPath",
        "mysql-connector-j-8.0.33.jar"
    )
'''
#print(PRODUCTION)
#print(DATABASE_IP)

spark = builder.getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

product_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3307/shop") \
    .option("dbtable", "shop.product") \
    .option("user", "root") \
    .option("password", "root") \
    .load()

order_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3307/shop") \
    .option("dbtable", "shop.order") \
    .option("user", "root") \
    .option("password", "root") \
    .load()

product_order_data_frame = spark.read \
    .format("jdbc") \
    .option("driver", "com.mysql.cj.jdbc.Driver") \
    .option("url", "jdbc:mysql://shopDb:3307/shop") \
    .option("dbtable", "shop.product_order") \
    .option("user", "root") \
    .option("password", "root") \
    .load()

# people_data_frame.show ( )
# result = people_data_frame.filter ( people_data_frame["gender"] == "Male" ).collect ( )
# print ( result )

#result = people_data_frame.join(
#    messages_data_frame,
#    messages_data_frame["person_id"] == people_data_frame["id"]
#).groupBy(people_data_frame["first_name"]).count().collect()
#print(result)

# Join the dataframes and calculate product statistics
product_statistics_data_frame = product_data_frame \
    .join(product_order_data_frame, product_data_frame["id"] == product_order_data_frame["product_id"], "inner") \
    .join(order_data_frame, order_data_frame["id"] == product_order_data_frame["order_id"], "inner") \
    .groupBy(product_data_frame["naziv"]) \
    .agg(
        {"product_order.kolicina": "sum", "order.status": "count"}
    ) \
    .withColumnRenamed("sum(kolicina)", "sold") \
    .withColumnRenamed("count(status)", "waiting") \
    .select(col("naziv").alias("name"), col("sold"), col("waiting"))

# Convert the dataframe to a list of dictionaries
statistics = product_statistics_data_frame.toJSON().collect()
statistics = [json.loads(stat) for stat in statistics]

# Create the response
response = {"statistics": statistics}

# Write the response to a file
with open("/app/product_statistics.json", "w") as file:
    json.dump(response, file)

spark.stop()

