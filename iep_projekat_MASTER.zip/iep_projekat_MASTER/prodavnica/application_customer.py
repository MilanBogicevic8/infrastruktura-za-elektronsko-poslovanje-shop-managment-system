import json

from eth_utils import address
from flask import Flask
from flask import jsonify
from flask import request
from flask import Response

from configuration import Configuration

from sqlalchemy import and_

from models import database
from models import Product
from models import Category
from models import ProductCategory
from models import Order
from models import ProductOrder

from functools import wraps

from flask_jwt_extended import JWTManager
from flask_jwt_extended import verify_jwt_in_request
from flask_jwt_extended import get_jwt


from web3 import Web3
from web3 import HTTPProvider
from web3 import Account

from eth_account import Account

application=Flask(__name__)
application.config.from_object(Configuration)

jwt=JWTManager(application)

web3=Web3(HTTPProvider("http://blockchain_ganache:8545"))

#from tokens.py vezbe 10
def read_file ( path ):
    with open ( path, "r" ) as file:
        return file.read ( )


INVALID_QUANTITY = "Invalid product quantity for request number {}."
INVALID_PRODUCT_FOR_REQUEST = "Invalid product for request number {}."

REQUESTS_MISSING = "Field requests is missing."
PRODUCT_ID_MISSING = "Product id is missing for request number {}."




#dekorater za proveru prava pristupa
def roleCheck(role):
    def innerRoleCheck(function):
        @wraps(function)
        def decorator(*arguments, **keywordArguments):
            verify_jwt_in_request()
            claims = get_jwt()
            if ("roles" in claims) and (role in claims["roles"]):
                return function(*arguments, **keywordArguments)
            else:
                return jsonify({'msg': 'Missing Authorization Header'}), 401

        return decorator

    return innerRoleCheck



@application.route("/search",methods=["GET"])
@roleCheck(role="customer")
def search():
    productName = request.args.get("name", "")
    categoryName = request.args.get("category", "")

    categories = Category.query.join(ProductCategory).join(Product).filter(
        and_(Category.naziv.contains(categoryName), Product.naziv.contains(productName))).distinct().all()
    products = Product.query.join(ProductCategory).join(Category).filter(
        and_(Category.naziv.contains(categoryName), Product.naziv.contains(productName))).distinct().all()

    lista_kategorija = []
    for category in categories:
        # print(category);
        lista_kategorija.append(category.naziv)

    lista_proizvoda = []
    for product in products:
        # print(product)
        productCategories = Category.query.join(ProductCategory).filter(
            ProductCategory.product_id == product.id
        ).distinct().all()

        proizvodove_kategorije = []
        for category in productCategories:
            proizvodove_kategorije.append(category.naziv)

        output = {
            "categories": proizvodove_kategorije,
            "id": product.id,
            "name": product.naziv,
            "price": product.cena
        }
        lista_proizvoda.append(output)

    return Response(json.dumps({"categories": lista_kategorija, "products": lista_proizvoda}), status=200)


@application.route("/order",methods=["POST"])
@roleCheck(role='customer')
def order():
    requests = request.json.get("requests", "")



    if len(requests) == 0:
        return Response(json.dumps({'message': "Field requests is missing."}), status=400)

    products = []
    requestedQuantities = []
    totalPrice = 0

    for i in range(len(requests)):
        productId = requests[i].get('id', '')
        quantity = requests[i].get('quantity', '')

        if productId == '':
            return Response(json.dumps({'message': "Product id is missing for request number " + str(i) + "."}),status=400)
        if quantity == '':
            return Response(json.dumps({'message': "Product quantity is missing for request number " + str(i) + "."}),status=400)

        try:
            if(int(productId)<=0):
                return {"message": f"Invalid product id for request number {i}."}, 400
        except ValueError:
            return Response(json.dumps({'message': "Invalid product id for request number " + str(i) + "."}),status=400)

        try:
            if(int(quantity)<=0):
                return {"message": f"Invalid product quantity for request number {i}."}, 400
        except ValueError:
            return Response(json.dumps({'message': "Invalid product quantity for request number " + str(i) + "."}),status=400)

        if productId <= 0:
            return Response(json.dumps({'message': "Invalid product id for request number " + str(i) + "."}),status=400)
        if quantity <= 0:
            return Response(json.dumps({'message': "Invalid product quantity for request number " + str(i) + "."}),status=400)

        #mozda moze sa first() umesto all()
        product = Product.query.filter(Product.id == productId).all()

        if len(product) == 0:
            return Response(json.dumps({'message': "Invalid product for request number " + str(i) + "."}), status=400)

        product = product[0]

        products.append(product)
        requestedQuantities.append(quantity)
        totalPrice += product.cena * quantity

    address = request.json.get("address")

    if ((address is None) or (address=='')):
        return Response(json.dumps({'message':"Field address is missing."}),status=400)
    if(web3.is_address(address)==False):
        return Response(json.dumps({'message':"Invalid address."}), status=400)

    private_key = ""

    #with open("../Tests/keys.json", "r") as file:
    #    private_key = Account.decrypt(file.read(), "iep_project").hex()


    bytecode = read_file("./solidity/output/PurchaseContract.bin")
    abi = read_file("./solidity/output/PurchaseContract.abi")

    contract = web3.eth.contract(bytecode=bytecode, abi=abi)


    ugovor= contract.constructor(address).transact({
        "from": web3.eth.accounts[0]    #troskove kreiranja ugovora snosi owner
    })
    racun= web3.eth.wait_for_transaction_receipt(ugovor)



    #nonce = web3.eth.get_transaction_count(address)
    #print(contract)
    #print(nonce)
    # build transaction
    '''transaction = contract.constructor(address).build_transaction(
        {
            "chainId": 1337,
            "gasPrice": web3.eth.gas_price,
            "from": address,
            "nonce": nonce,
        }
    )'''
    # Sign the transaction
    #sign_transaction = web3.eth.account.sign_transaction(transaction, private_key=private_key)
    print("Deploying Contract!")

    # Send the transaction
    #transaction_hash = web3.eth.send_raw_transaction(sign_transaction.rawTransaction)
    # Wait for the transaction to be mined, and get the transaction receipt
    print("Waiting for transaction to finish...")
    #transaction_receipt = web3.eth.wait_for_transaction_receipt(transaction_hash)
    #print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")


    email = get_jwt()['email']
    porudbina = Order(blockchain_adresa=racun.contractAddress,cena=totalPrice, email_adresa=email,adresa_kupca=address)
    database.session.add(porudbina)
    database.session.commit()

    for product, requestedQuantity in zip(products, requestedQuantities):

        po = ProductOrder(product_id=product.id, order_id=porudbina.id, kolicina=requestedQuantity,cena=product.cena)
        database.session.add(po)
        database.session.commit()

    return Response(json.dumps({'id': porudbina.id}), status=200)

@application.route("/status",methods=["GET"])
@roleCheck(role='customer')
def status():
    email = get_jwt()['email']

    orders = Order.query.filter(Order.email_adresa == email)

    resultJSON = {
        'orders': [
            {
                'products': [
                    {
                        'categories': [cat.naziv for cat in product.kategorije],
                        'name': product.naziv,
                        'price': ProductOrder.query.filter(and_(ProductOrder.product_id == product.id, ProductOrder.order_id == order.id)).first().cena,
                        'quantity': ProductOrder.query.filter(and_(ProductOrder.product_id == product.id, ProductOrder.order_id == order.id)).first().kolicina,
                    }
                    for product in Product.query.join(ProductOrder).filter(ProductOrder.order_id == order.id).all()
                ],
                'price': order.cena,
                'status': order.status,
                'timestamp': order.datum_kreiranja.strftime('%Y-%m-%dT%H:%M:%SZ')
            }
            for order in orders
        ]
    }

    return Response(json.dumps(resultJSON), status=200)

# Funkcija za dekriptovanje ključeva #account info vezbe 10
'''
oblik kljuca:
{
  "id": 3,
  "keys": {
    "version": 3,
    "id": "457ebaff-635d-4385-8a23-59064e65332b",
    "address": "6f55bb52a5131bb8a45efa48df25c5961cc03782",
    "Crypto": {
      "ciphertext": "3ebb275069f4d440dd46f1f7e9a48d4454dc3de6acb840504a42de7f5f354596",
      "cipherparams": {
        "iv": "758a694b3adbede63b4204d8ef4ccd16"
      },
      "cipher": "aes-128-ctr",
      "kdf": "scrypt",
      "kdfparams": {
        "dklen": 32,
        "salt": "eff8cb2da4409673d0b4db1fa6cb2af1f93e40a639098246547f93b7fc82cdc8",
        "n": 8192,
        "r": 8,
        "p": 1
      },
      "mac": "c0affb50a0f9f037a240146387b701ddf37045d84a620bb1c50fd11ad2a4b657"
    }
  },
  "passphrase": "iep_project"
}

'''
def decrypt_keys(keys, passphrase):
    keys = keys.replace("'", '"')
    keys = json.loads(keys)

    address = web3.to_checksum_address(keys["address"])
    private_key = Account.decrypt(keys, passphrase).hex()
    print(address, flush=True)
    print(private_key,flush=True)
    return (address, private_key)


@application.route("/delivered",methods=["POST"])
@roleCheck(role='customer')
def deliver():
    # Provera polja id u telu zahteva
    id=request.json.get("id");
    if id is None:
        return Response(json.dumps({"message": "Missing order id."}), 400);

    order_id = request.json["id"]
    try:
       order_id=int(order_id)
    except ValueError:
        return Response(json.dumps({"message": "Invalid order id."}), status=400)

    if(order_id<0): #mozda <=
        return Response(json.dumps({"message": "Invalid order id."}), status=400)

    try:
        # Pronalaženje narudžbine u bazi
        order = Order.query.filter(Order.id==order_id).first();

        if order is None:
            return Response(json.dumps({"message": "Invalid order id."}), status=400)

        if order.status != "PENDING":
            return Response(json.dumps({"message": "Invalid order id."}), status=400)


        keys=request.json.get("keys")
        if(keys is None):
            return Response(json.dumps({"message":"Missing keys."}),status=400);

        if(keys==""):
            return Response(json.dumps({"message": "Missing keys."}), status=400);

        passphrase=request.json.get("passphrase");
        if(passphrase is None):
            return Response(json.dumps({"message":"Missing passphrase."}),status=400);
        if(passphrase==""):
            return Response(json.dumps({"message":"Missing passphrase."}),status=400);

        # Dekriptovanje ključeva
        try:
            address,private_key= decrypt_keys(keys, passphrase)
        except ValueError as e:
            #return Response(json.dumps({"message": "Invalid credentials."+str(e)}), status=400)
            return Response(json.dumps({"message": "Invalid credentials."}), status=400)

        if address != order.adresa_kupca:
            return Response(json.dumps({"message": "Invalid customer account."}), status=400)


        bytecode = read_file("./solidity/output/PurchaseContract.bin")
        abi=read_file("./solidity/output/PurchaseContract.abi");

        # Provera da li je kupac izvršio transfer sredstava na odgovarajući ugovor
        contract = web3.eth.contract(address=order.blockchain_adresa, abi=abi)
        transfer_completed = contract.functions.getPaid().call()

        if not transfer_completed:
            return Response(json.dumps({"message": "Transfer not complete."}), status=400)

        '''if( order.status!="PENDING"):
            return Response(json.dumps({"message":"Delivery not complete."}),status=400)'''
        nonce=web3.eth.get_transaction_count(address);

        transfer=web3.eth.contract(
            address=order.blockchain_adresa, abi=abi,bytecode=bytecode)\
            .functions.confirmDelivery().build_transaction(
            {
                "gasPrice": 21000,   #web3.eth.gas_price,
                "from": address,
                "nonce": nonce
            }
        );

        # Sign the transaction
        sign_transaction = web3.eth.account.sign_transaction(transfer, private_key=private_key)
        print("Deploying Contract!")
        # Send the transaction
        transaction_hash = web3.eth.send_raw_transaction(sign_transaction.rawTransaction)
        # Wait for the transaction to be mined, and get the transaction receipt
        print("Waiting for transaction to finish...")
        transaction_receipt = web3.eth.wait_for_transaction_receipt(transaction_hash)
        #print(f"Done! Contract deployed to {transaction_receipt.contractAddress}")

        # Ažuriranje statusa narudžbine na COMPLETED
        order.status = "COMPLETE"
        database.session.commit()

        return {}, 200
    except ValueError:
        return Response(json.dumps({"message":"Invalid customer account."}),status=400)
    except Exception as e:#ovde dodaj deliveru not complete ukoliko niko od kurira nije pokupio narudbinu, bool neki u ugovoru,vrv greska u postavci, gore to proveravam
        return jsonify({"message": str(e)}), 500

@application.route("/pay",methods=["POST"])
@roleCheck(role='customer')
def cutomer_payment():
    try:
        id=request.json.get("id");
        if(id is None):
            return Response(json.dumps({"message":"Missing order id."}),status=400);
        try:
            id=int(id)
        except ValueError:
            return Response(json.dumps({"message":"Invalid order id."}),status=400)

        if(id<0):
            return Response(json.dumps({"message": "Invalid order id."}), status=400)

        order=Order.query.filter(Order.id==id).first();

        if(order is None):
            return Response(json.dumps({"message": "Invalid order id."}), status=400)

        keys=request.json.get("keys");

        if(keys is None):
            return Response(json.dumps({"message":"Missing keys."}),status=400)
        if(len(keys)==0):
            return Response(json.dumps({"message": "Missing keys."}), status=400)

        passphrase=request.json.get("passphrase")

        if(passphrase is None):
            return Response(json.dumps({"message":"Missing passphrase."}),status=400)

        if(len(passphrase)==0):
            return Response(json.dumps({"message":"Missing passphrase."}),status=400)

        bytecode = read_file("./solidity/output/PurchaseContract.bin")
        abi = read_file("./solidity/output/PurchaseContract.abi");

        address, private_key = decrypt_keys(keys, passphrase)

        if(web3.eth.get_balance(address)<order.cena):
            #return Response(json.dumps({"message":"Insufficient funds."+"address:"+str(address)+"key:"+str(private_key)+"balance:"+str(web3.eth.get_balance(address))+" cena:"+str(order.cena)+"bool:"+str(web3.eth.get_balance(address)<order.cena)}),status=400)
            return Response(json.dumps({"message": "Insufficient funds."}), status=400)

        print(web3.eth.get_balance(address),flush=True);
        contract = web3.eth.contract(address=order.blockchain_adresa, abi=abi,bytecode=bytecode)
        transfer_completed = contract.functions.getPaid().call()

        if transfer_completed==True:
            return Response(json.dumps({"message":"Transfer already complete."}),status=400)


        ugovor=web3.eth.contract(address=order.blockchain_adresa,abi=abi,bytecode=bytecode)
        nonce = web3.eth.get_transaction_count(address);

        transakcija=ugovor.functions.submitPayment().build_transaction(
            {
                "from":address,
                "nonce":nonce,
                "gasPrice": 21000,                 #web3.eth.gas_price,
                "value": int(order.cena)
            }
        )

        # Sign the transaction
        sign_store_contact = web3.eth.account.sign_transaction(
            transakcija, private_key=private_key
        )
        # Send the transaction
        send_store_contact = web3.eth.send_raw_transaction(sign_store_contact.rawTransaction)
        transaction_receipt = web3.eth.wait_for_transaction_receipt(send_store_contact)

        return {},200

    except ValueError:
        return Response(json.dumps({"message":"Invalid credentials."}),status=400)
    except Exception as e:
        return jsonify({"message": str(e)}), 500

@application.route("/balance",methods=["POST"])
def check_balance():
    address=request.json.get("address");

    bytecode = read_file("./solidity/output/PurchaseContract.bin")
    abi = read_file("./solidity/output/PurchaseContract.abi");


    return Response(str(web3.eth.get_balance(address)),status=200)

'''@application.route("/format",methods=["POST"])
def format_address_private_key():

    address=request.json.get("address")
    private_key=request.json.get("private_key");

    # Kreiranje JSON objekta za zaglavlje
    header = {
        "version": 3,
        "id": str(uuid.uuid4()),
        "address": address,
        "Crypto": {
            "ciphertext": "",
            "cipherparams": {
                "iv": ""
            },
            "cipher": "aes-128-ctr",
            "kdf": "scrypt",
            "kdfparams": {
                "dklen": 32,
                "salt": "",
                "n": 8192,
                "r": 8,
                "p": 1
            },
            "mac": ""
        }
    }

    encrypted_key = Web3.toHex(Web3.toBytes(hexstr=private_key))
    crypto = Web3.eth.account.encrypt(encrypted_key, "your_password")
    header["Crypto"]["ciphertext"] = crypto["ciphertext"]
    header["Crypto"]["cipherparams"]["iv"] = crypto["cipherparams"]["iv"]
    header["Crypto"]["kdfparams"]["salt"] = crypto["kdfparams"]["salt"]
    header["Crypto"]["mac"] = crypto["mac"]

    # Konvertovanje zaglavlja u JSON format
    json_header = json.dumps(header)

    return Response(json_header,status=200)


return json_header
'''


if(__name__=="__main__"):
    database.init_app(application)
    application.run(debug=True,host="0.0.0.0",port=5002)