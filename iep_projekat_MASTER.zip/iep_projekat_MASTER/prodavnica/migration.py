import shutil

from flask import Flask
from flask_migrate import Migrate
from flask_migrate import init
from flask_migrate import migrate
from flask_migrate import upgrade
from sqlalchemy_utils import database_exists, create_database
from sqlalchemy_utils import drop_database;
from models import Product
from models import Order
from models import Category
from models import ProductOrder
from models import ProductCategory
from models import database


from configuration import Configuration

application=Flask(__name__)
application.config.from_object(Configuration)

migration=Migrate(application,database)

if database_exists(application.config['SQLALCHEMY_DATABASE_URI']):
    drop_database(application.config['SQLALCHEMY_DATABASE_URI'])

create_database(application.config['SQLALCHEMY_DATABASE_URI'])


database.init_app(application);


with application.app_context() as context:
    try:
        shutil.rmtree('migrations')
    except Exception:
        pass

    init();
    migrate(message="Shop is now open!");
    upgrade();


