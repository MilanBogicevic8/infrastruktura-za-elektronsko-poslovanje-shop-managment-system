import json
import io
import csv
import os
import subprocess
#import statistika

from flask import Flask
from flask import jsonify
from flask import request
from flask import Response
from functools import wraps

from flask_jwt_extended import verify_jwt_in_request
from flask_jwt_extended import get_jwt
from flask_jwt_extended import JWTManager

from models import database
from models import Product
from models import Category
from models import Order
from models import ProductCategory
from models import ProductOrder

from sqlalchemy import func
from sqlalchemy import and_
from sqlalchemy import select

from sqlalchemy import func, case
from sqlalchemy.orm import aliased

#from statistika import database_product_statistics


from configuration import Configuration;

application=Flask(__name__)
application.config.from_object(Configuration)

jwt=JWTManager(application)



#dekorater za proveru prava pristupa
def roleCheck(role):
    def innerRoleCheck(function):
        @wraps(function)
        def decorator(*arguments, **keywordArguments):
            verify_jwt_in_request()
            claims = get_jwt()
            if ("roles" in claims) and (role in claims["roles"]):
                return function(*arguments, **keywordArguments)
            else:
                return jsonify({'msg': 'Missing Authorization Header'}), 401

        return decorator

    return innerRoleCheck

@application.route("/",methods=["GET"])
def index():
    return "Hello world";

def extract_json(input_string):
    lines = input_string.split('\n')  # Razdvajanje stringa na linije na osnovu znaka za prelazak u novi red
    print(lines,flush=True)
    json_line = lines[-2]  # Poslednja linija sadrži JSON objekat
    json_data = json_line.strip()  # Uklanjanje eventualnih razmaka na početku ili kraju linije
    #json_data=json_data.replace("'","");
    return json_data

def process_json(json_string):
    data = json.loads(json_string)
    statistics = data['statistics']

    # Izbaci elemente sa waiting i sold postavljenim na null
    statistics = [item for item in statistics if item['waiting']!=0 or item['sold']!=0]

    # Zameni preostale null vrednosti sa 0
    for item in statistics:
        if item['waiting']==0:
            item['waiting'] = 0
        if item['sold']==0:
            item['sold'] = 0

    data["statistics"] =statistics;
    # Konvertuj rezultujući niz u JSON string
    processed_json = json.dumps(data)

    return data


@application.route("/update", methods=["POST"])
@roleCheck(role="owner")
def update():
    # dohvatanje fajla
    file = request.files.get("file", None)

    # provera da li je poslat
    if not file:
        return Response(json.dumps({"message": "Field file is missing."}), status=400)

    # otvaranje strima i parsing
    sadrzaj = file.stream.read().decode("utf-8")
    stream = io.StringIO(sadrzaj)
    reader = csv.reader(stream)

    proizvodi = []
    broj = 0

    for row in reader:
        if len(row) != 3:
            return Response(json.dumps({'message': "Incorrect number of values on line " + str(broj) + "."}),
                            status=400)
        broj += 1

    # Postavljanje položaja čitača na početak datoteke
    stream.seek(0)
    reader = csv.reader(stream)
    broj = 0

    for row in reader:
        try:
            if float(row[2]) <= 0:
                return {"message": f"Incorrect price on line {broj}."}, 400
        except ValueError:
            return {"message": f"Incorrect price on line {broj}."}, 400
        broj += 1

    # Postavljanje položaja čitača na početak datoteke
    stream.seek(0)
    reader = csv.reader(stream)

    broj = 0
    proizvod_list = []

    for row in reader:
        kategorije = row[0]
        naziv = row[1]
        cena = row[2]

        prod = Product.query.filter(Product.naziv == naziv).first()

        if prod is not None:
            return {"message": f"Product {naziv} already exists."}, 400

        kategorije_lista = kategorije.split("|")
        kat_for_prod = []

        for k in kategorije_lista:
            upit = Category.query.filter(Category.naziv == k).first()

            if upit is None:
                upit = Category(naziv=k)
                database.session.add(upit)
                database.session.commit()

            kat_for_prod.append(upit)

        proizvod_baza = Product(naziv=naziv, cena=cena, kategorije=kat_for_prod)
        proizvod_list.append(proizvod_baza)
        broj += 1

    database.session.add_all(proizvod_list)
    database.session.commit()
    return Response(status=200)


#ovo treba sparkom vrv
@application.route("/product_statistics",methods=["GET"])
@roleCheck(role="owner")
def product_statistics( ):
    #return statistika.database_product_statistics();

    # Dohvatanje statistike proizvoda
    '''
    statistics = []

    # Iteracija kroz sve proizvode
    products = Product.query.all()
    for product in products:
        sold = 0
        waiting = 0

        # Dohvatanje povezanih objekata ProductOrder za dati proizvod
        product_orders = ProductOrder.query.filter_by(product_id=product.id).all()

        # Iteracija kroz sve ProductOrder objekte
        for product_order in product_orders:
            order = Order.query.get(product_order.order_id)

            if order.status == "COMPLETE":
                sold += product_order.kolicina
            else:
                waiting += product_order.kolicina

        # Kreiranje objekta statistike za proizvod
        product_stat = {
            "name": product.naziv,
            "sold": sold,
            "waiting": waiting
        }

        # Dodavanje objekta statistike u listu
        if(product_stat["sold"]!=0 or product_stat["waiting"]!=0):
            statistics.append(product_stat)

    # Kreiranje odgovora
    response = {
        "statistics": statistics
    }

    return jsonify(response), 200


    # Poziv funkcije product_statistics
    #result = database_product_statistics()

    # Vraćanje jsonify objekta i statusa 200
    #return jsonify(result), 200
    #return "OK";
    '''

    os.environ["SPARK_APPLICATION_PYTHON_LOCATION"] = "/app/proizvod_statistika.py"

    os.environ["SPARK_SUBMIT_ARGS"] = "--driver-class-path /app/mysql-connector-j-8.0.33.jar --jars /app/mysql-connector-j-8.0.33.jar"

    print("poziv", flush=True)
    result = subprocess.check_output(["/template.sh"]).decode()

    print(result, flush=True)

    result = extract_json(result)
    print(result, flush=True)
    # Vraćanje statistike kao odgovor
    result = process_json(result);
    print(result, flush=True)

    return jsonify(result), 200

@application.route("/category_statistics",methods=["GET"])
@roleCheck(role="owner")
def category_statistics( ):
    #return statistika.database_category_statistics();
    '''resultJSON = {
        'statistics': [
            cat.naziv for cat in Category.query.outerjoin(ProductCategory)
            .outerjoin(Product)
            .outerjoin(ProductOrder)
            .group_by(Category.id)
            .order_by(func.sum(ProductOrder.kolicina if (ProductOrder.order.status=="COMPLETE") else 0).desc())
            .order_by(Category.naziv)
            .all()
        ]
    }'''

    '''resultJSON = {
        'statistics': [
            cat.naziv for cat in Category.query.outerjoin(ProductCategory)
            .outerjoin(Product)
            .outerjoin(ProductOrder)
            .group_by(Category.id)
            .order_by(func.sum(ProductOrder.kolicina if(Order.query.filter(and_(Order.id==ProductOrder.order_id,Order.status=="COMPLETE")).first() is not None) else 0).desc())
            .order_by(Category.naziv)
            .all()
        ]
    }'''

    # Kreiranje podupita za filtriranje redova sa statusom "COMPLETE"
    '''complete_orders_subquery = Order.query.filter_by(status="COMPLETE").subquery()

    resultJSON = {
        'statistics': [
            cat.naziv for cat in Category.query.outerjoin(ProductCategory)
            .outerjoin(Product)
            .outerjoin(ProductOrder)
            .join(complete_orders_subquery,
                  ProductOrder.order)  # Spajanje na podupit sa filtriranim "COMPLETE" redovima
            .group_by(Category.id)
            .order_by(func.sum(ProductOrder.kolicina).desc(), Category.naziv)  # Promena redosleda sortiranja
            .all()
        ]
    }
    # Order.query.filter(and_(ProductOrder.order_id == Order.id, Order.status == "COMPLETE")).first()
    return Response(json.dumps(resultJSON), status=200)'''
    '''
    categories = Category.query.all()
    category_dict = {}

    for category in categories:
        category_dict[category.naziv] = 0

    for product in Product.query.all():
        orders = product.narudbine
        for order in orders:
            if order.status == "COMPLETE":
                product_order = ProductOrder.query.filter(
                    and_(ProductOrder.product_id == product.id, ProductOrder.order_id == order.id)).first()
                if product_order:
                    for category in product.kategorije:
                        category_dict[category.naziv] += product_order.kolicina

    result = sorted(category_dict.items(), key=lambda x: (-x[1], x[0]))
    statistics = [item[0] for item in result]

    return jsonify({"statistics": statistics})
    '''
    os.environ["SPARK_APPLICATION_PYTHON_LOCATION"] = "/app/kategorije_statistika.py"

    os.environ["SPARK_SUBMIT_ARGS"] = "--driver-class-path /app/mysql-connector-j-8.0.33.jar --jars /app/mysql-connector-j-8.0.33.jar"

    result = subprocess.check_output(["/template.sh"]).decode()
    print(result, flush=True)
    result = extract_json(result)
    print(result, flush=True)

    # Vraćanje odgovora kao JSON objekta
    return jsonify(json.loads(result)), 200

@application.route("/search")
def search( ):
    pass
if(__name__=="__main__"):
    database.init_app(application)
    application.run(debug=True,host="0.0.0.0",port=5001)