import json

from flask import Flask
from flask import jsonify
from flask import request
from flask import Response

from models import database
from models import Product
from models import Order
from models import Category
from models import ProductCategory
from models import ProductOrder

from sqlalchemy import and_;

from flask_jwt_extended import JWTManager
from flask_jwt_extended import verify_jwt_in_request
from flask_jwt_extended import get_jwt


from configuration import Configuration

from functools import wraps

from web3 import Web3
from web3 import HTTPProvider
from web3 import Account


web3=Web3(HTTPProvider("http://blockchain_ganache:8545"))

application=Flask(__name__)
application.config.from_object(Configuration)

jwt=JWTManager(application)

#dekorater za proveru prava pristupa
def roleCheck(role):
    def innerRoleCheck(function):
        @wraps(function)
        def decorator(*arguments, **keywordArguments):
            verify_jwt_in_request()
            claims = get_jwt()
            if ("roles" in claims) and (role in claims["roles"]):
                return function(*arguments, **keywordArguments)
            else:
                return jsonify({'msg': 'Missing Authorization Header'}), 401

        return decorator

    return innerRoleCheck


@application.route("/orders_to_deliver",methods=["GET"])
@roleCheck(role="courier")
def order_to_delliver_view():
    orders=Order.query.filter(and_(Order.status!="PENDING" , Order.status!="COMPLETE")).all()

    result = {"orders": []}

    for order in orders:
        order_data = {
            "id": order.id,
            "email": order.email_adresa
        }
        result["orders"].append(order_data)

    return result

#from tokens.py vezbe 10
def read_file ( path ):
    with open ( path, "r" ) as file:
        return file.read ( )

def decrypt_keys(keys, passphrase):
    keys = json.loads(keys)

    address = web3.to_checksum_address(keys["address"])
    private_key = Account.decrypt(keys, passphrase).hex()

    return (address, private_key)


@application.route("/pick_up_order",methods=["POST"])
@roleCheck(role="courier")
def pick_up():
    # Provera polja id u telu zahteva
    id=request.json.get("id")
    if id is None:
        return Response(json.dumps({"message": "Missing order id."}), status=400)

    order_id = id;

    try:
       order_id=int(order_id)
    except ValueError:
        return Response(json.dumps({"message": "Invalid order id."}), status=400)

    if(order_id<0): #mozda <=
        return Response(json.dumps({"message": "Invalid order id."}), status=400)
    try:
        # Pronalaženje narudžbine u bazi
        order = Order.query.filter(Order.id==order_id).first()

        if order is None:
            return Response(json.dumps({"message": "Invalid order id."}), status=400)

        if order.status != "CREATED":
            return Response(json.dumps({"message": "Invalid order id."}), status=400)

        address=request.json.get("address")

        if(address is None):
            return Response(json.dumps({"message":"Missing address."}),status=400)
        if(len(address)==0):
            return Response(json.dumps({"message":"Missing address."}),status=400)

        if(web3.is_address(address)==False):
            return Response(json.dumps({"message":"Invalid address."}),status=400)

        bytecode = read_file("./solidity/output/PurchaseContract.bin");
        abi = read_file("./solidity/output/PurchaseContract.abi");

        # Provera da li je kupac izvršio transfer sredstava na odgovarajući ugovor
        contract = web3.eth.contract(address=order.blockchain_adresa, abi=abi)
        transfer_completed = contract.functions.getPaid().call()

        if not transfer_completed:
            return Response(json.dumps({"message": "Transfer not complete."}), status=400)

        transakcija=web3.eth.contract(address=address,abi=abi,bytecode=bytecode).functions.bindCourier(address).transact({"from":web3.eth.accounts[0]})


        # Ažuriranje statusa narudžbine na PENDING
        order.status = "PENDING"
        database.session.commit()

        return {}, 200

    except Exception as e:
        return jsonify({"message": str(e)}), 500



if(__name__=="__main__"):
    database.init_app(application)
    application.run(debug=True,host="0.0.0.0",port=5003)