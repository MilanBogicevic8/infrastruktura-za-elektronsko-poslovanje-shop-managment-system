from flask import Flask
from flask import jsonify
import os
import subprocess
import json



application=Flask(__name__)

@application.route("/product",methods=["GET"])
def database_product_statistics():
    os.environ["SPARK_APPLICATION_PYTHON_LOCATION"] = "/app/proizvod_statistika.py"

    os.environ["SPARK_SUBMIT_ARGS"] = "--driver-class-path /app/mysql-connector-j-8.0.33.jar --jars /app/mysql-connector-j-8.0.33.jar"

    #result = subprocess.check_output(["/template.sh"])

    # Izvršavanje skripte proizvod_statistika.py
    subprocess.call(["python", "/app/proizvod_statistika.py"])

    # Učitavanje statistike iz datoteke
    #with open("/app/product_statistics.json", "r") as file:
    #    data = json.load(file)

    # Uklanjanje datoteke
    #os.remove("/app/product_statistics.json")

    # Vraćanje statistike kao odgovor
    #return jsonify(data), 200
    return "OK";


    #return result.decode()




if(__name__=="__main__"):
    application.run(debug=True,host="0.0.0.0", port=5004)
