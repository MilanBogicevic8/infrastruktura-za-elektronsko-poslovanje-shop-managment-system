
from flask_sqlalchemy import SQLAlchemy

import datetime

database=SQLAlchemy();


class ProductOrder(database.Model):
    id=database.Column(database.Integer,primary_key=True)
    product_id=database.Column(database.Integer,database.ForeignKey("product.id"))
    order_id=database.Column(database.Integer,database.ForeignKey("order.id"))
    kolicina=database.Column(database.Integer)
    cena=database.Column(database.Float)

class ProductCategory(database.Model):
    id=database.Column(database.Integer,primary_key=True)
    product_id=database.Column(database.Integer,database.ForeignKey("product.id"))
    category_id=database.Column(database.Integer,database.ForeignKey("category.id"))

class Order(database.Model):

    id=database.Column(database.Integer,primary_key=True);
    email_adresa = database.Column(database.String(256), nullable=False)
    cena = database.Column(database.Float, nullable=False);
    datum_kreiranja = database.Column(database.DateTime, nullable=False, default=datetime.datetime.now());
    status=database.Column(database.String(256), nullable=False,default="CREATED");
    blockchain_adresa=database.Column(database.String(256));
    adresa_kupca=database.Column(database.String(256))
    #relacije
    proizvodi=database.relationship("Product",secondary=ProductOrder.__table__,back_populates="narudbine")

class Product(database.Model):
    id=database.Column(database.Integer,primary_key=True);
    cena=database.Column(database.Float,nullable=False)
    naziv=database.Column(database.String(256),nullable=False)
    kolicina=database.Column(database.Integer)
    #relacije
    narudbine=database.relationship("Order",secondary=ProductOrder.__table__,back_populates="proizvodi")
    kategorije=database.relationship("Category",secondary=ProductCategory.__table__,back_populates="proizvodi")

class Category(database.Model):

    id=database.Column(database.Integer,primary_key=True)
    naziv=database.Column(database.String(256),nullable=False)
    #relacije
    proizvodi=database.relationship("Product",secondary=ProductCategory.__table__,back_populates="kategorije")
    def __repr__(self):
        return self.naziv



